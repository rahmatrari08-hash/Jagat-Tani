package com.example.jagat_tani

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
